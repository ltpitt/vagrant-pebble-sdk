var group___app_comm =
[
    [ "app_comm_get_sniff_interval", "group___app_comm.html#gabc354bbdd9bb78e94ba64c91363bbcf6", null ],
    [ "app_comm_set_sniff_interval", "group___app_comm.html#gad7ebc2401ed636dddfcb8f5cb67f8c37", null ],
    [ "SniffInterval", "group___app_comm.html#gad85d78fd5b9d36fb69242afa57e79f48", [
      [ "SNIFF_INTERVAL_NORMAL", "group___app_comm.html#ggad85d78fd5b9d36fb69242afa57e79f48a3b964e796c51c86c94eadf17b8dbcf17", null ],
      [ "SNIFF_INTERVAL_REDUCED", "group___app_comm.html#ggad85d78fd5b9d36fb69242afa57e79f48a8de75571a0bcf3ac565ced0628577382", null ]
    ] ]
];