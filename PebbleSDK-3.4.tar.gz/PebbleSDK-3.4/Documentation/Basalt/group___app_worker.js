var group___app_worker =
[
    [ "app_worker_is_running", "group___app_worker.html#ga6b92572431bb41d2e48144fec4929672", null ],
    [ "app_worker_kill", "group___app_worker.html#ga9a99c4ec6caf05627b53c49349f96e16", null ],
    [ "app_worker_launch", "group___app_worker.html#ga84f6780cd67e429f9b569eee36862d9a", null ],
    [ "app_worker_message_subscribe", "group___app_worker.html#gae93a0baab484dda8e75e3d5699fd7463", null ],
    [ "app_worker_message_unsubscribe", "group___app_worker.html#gabdd29f332fcaf8785fa2c73cf55addf3", null ],
    [ "app_worker_send_message", "group___app_worker.html#gac1a4c6ddd568429bded6373d00559fe0", null ],
    [ "AppWorkerMessageHandler", "group___app_worker.html#gaa8210c9a966a7294c870a3f2d03a59b9", null ],
    [ "AppWorkerResult", "group___app_worker.html#ga9732697a0e5e5718dfb265e061ec6a5d", [
      [ "APP_WORKER_RESULT_SUCCESS", "group___app_worker.html#gga9732697a0e5e5718dfb265e061ec6a5da94009622897d84fdf4d254c45a50b6bd", null ],
      [ "APP_WORKER_RESULT_NO_WORKER", "group___app_worker.html#gga9732697a0e5e5718dfb265e061ec6a5da9b36919aa66f787b95ae3dbe964c52ef", null ],
      [ "APP_WORKER_RESULT_DIFFERENT_APP", "group___app_worker.html#gga9732697a0e5e5718dfb265e061ec6a5da848f57b881f82a472439b8519b34732c", null ],
      [ "APP_WORKER_RESULT_NOT_RUNNING", "group___app_worker.html#gga9732697a0e5e5718dfb265e061ec6a5daed4965d390f0ca313b0daf102469ab54", null ],
      [ "APP_WORKER_RESULT_ALREADY_RUNNING", "group___app_worker.html#gga9732697a0e5e5718dfb265e061ec6a5daf21c365a14cf7268d9b5bc1bc37eb70a", null ],
      [ "APP_WORKER_RESULT_ASKING_CONFIRMATION", "group___app_worker.html#gga9732697a0e5e5718dfb265e061ec6a5dabca8de916dae9cf8dd28bd2b4fea9701", null ]
    ] ]
];