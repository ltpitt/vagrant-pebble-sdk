var group___battery_state_service =
[
    [ "battery_state_service_peek", "group___battery_state_service.html#ga0db4a30663844c173acb72f9204e6fcb", null ],
    [ "battery_state_service_subscribe", "group___battery_state_service.html#gadef114a27f24cc39e3ee5bda3756c865", null ],
    [ "battery_state_service_unsubscribe", "group___battery_state_service.html#ga787d24a03fe9a51cd61e24a9775efbc6", null ],
    [ "BatteryStateHandler", "group___battery_state_service.html#ga06471c5ea82209d1d80e0671bae09325", null ]
];