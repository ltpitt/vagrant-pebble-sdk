var group___bitmap_layer =
[
    [ "bitmap_layer_create", "group___bitmap_layer.html#ga3fa77622a7b1ea656f0503dfadeea712", null ],
    [ "bitmap_layer_destroy", "group___bitmap_layer.html#ga4ef30a7562a029d81e2956ab8068f0f5", null ],
    [ "bitmap_layer_get_bitmap", "group___bitmap_layer.html#gabe873bfc58601ef31730591192e16b45", null ],
    [ "bitmap_layer_get_layer", "group___bitmap_layer.html#gac9147d277bf7e57b5efcaebf8db3f0b2", null ],
    [ "bitmap_layer_set_alignment", "group___bitmap_layer.html#ga4c1765f9330890641c4c09ba7e894894", null ],
    [ "bitmap_layer_set_background_color", "group___bitmap_layer.html#ga67522a1e62431f0f68d161d83fb6d83e", null ],
    [ "bitmap_layer_set_bitmap", "group___bitmap_layer.html#ga919b52c2feb69c13966f4a52815377f8", null ],
    [ "bitmap_layer_set_compositing_mode", "group___bitmap_layer.html#ga7bc761ca8227881c5853cbc0e279385e", null ]
];