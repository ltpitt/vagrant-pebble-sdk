var group___clicks =
[
    [ "click_number_of_clicks_counted", "group___clicks.html#ga915cc99892dba2548494a9cc2b104dd7", null ],
    [ "click_recognizer_get_button_id", "group___clicks.html#ga373020cf179b975eb53636154a9c6ce5", null ],
    [ "click_recognizer_is_repeating", "group___clicks.html#gae9b3816aa6c1a9ebbc77ad621284b5b6", null ],
    [ "ClickConfigProvider", "group___clicks.html#ga9e12024e5769c1a76644a8cfd8288aff", null ],
    [ "ClickHandler", "group___clicks.html#ga8a973b4663a5171db84223d6ae79f28d", null ],
    [ "ClickRecognizerRef", "group___clicks.html#gab0f235645c2d1eb7b622542b59706085", null ],
    [ "ButtonId", "group___clicks.html#gaa60e15d86cfe7033f28c7d066c85266e", [
      [ "BUTTON_ID_BACK", "group___clicks.html#ggaa60e15d86cfe7033f28c7d066c85266eacb728f0712020cbbbf0d7f4f68359e8e", null ],
      [ "BUTTON_ID_UP", "group___clicks.html#ggaa60e15d86cfe7033f28c7d066c85266eafb03cb7921a8bb7893cd8093a1a5e9cb", null ],
      [ "BUTTON_ID_SELECT", "group___clicks.html#ggaa60e15d86cfe7033f28c7d066c85266ea98093cd31c917223780131cfafe91dec", null ],
      [ "BUTTON_ID_DOWN", "group___clicks.html#ggaa60e15d86cfe7033f28c7d066c85266ea65a919b8a0f4539acfb865eb2a2dd9d0", null ],
      [ "NUM_BUTTONS", "group___clicks.html#ggaa60e15d86cfe7033f28c7d066c85266eac81067fe4db9cdff7042b4d9efb5f4cb", null ]
    ] ]
];