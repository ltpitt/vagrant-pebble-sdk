var group___event_service =
[
    [ "AccelerometerService", "group___accelerometer_service.html", "group___accelerometer_service" ],
    [ "AppFocusService", "group___app_focus_service.html", "group___app_focus_service" ],
    [ "BatteryStateService", "group___battery_state_service.html", "group___battery_state_service" ],
    [ "BluetoothConnectionService", "group___bluetooth_connection_service.html", "group___bluetooth_connection_service" ],
    [ "CompassService", "group___compass_service.html", "group___compass_service" ],
    [ "TickTimerService", "group___tick_timer_service.html", "group___tick_timer_service" ]
];