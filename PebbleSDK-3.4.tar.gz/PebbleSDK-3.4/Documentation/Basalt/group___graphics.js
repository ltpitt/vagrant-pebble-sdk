var group___graphics =
[
    [ "Draw Commands", "group___draw_command.html", "group___draw_command" ],
    [ "Drawing Paths", "group___path_drawing.html", "group___path_drawing" ],
    [ "Drawing Primitives", "group___drawing.html", "group___drawing" ],
    [ "Drawing Text", "group___text_drawing.html", "group___text_drawing" ],
    [ "Fonts", "group___fonts.html", "group___fonts" ],
    [ "Graphics Context", "group___graphics_context.html", "group___graphics_context" ],
    [ "Graphics Types", "group___graphics_types.html", "group___graphics_types" ]
];