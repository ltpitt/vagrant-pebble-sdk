var group___graphics_context =
[
    [ "graphics_context_set_antialiased", "group___graphics_context.html#gaf3197c217e22f0cf3c360ba1daf624fc", null ],
    [ "graphics_context_set_compositing_mode", "group___graphics_context.html#ga64bc6cc5f86dabcd4b3cfa9fcffa328c", null ],
    [ "graphics_context_set_fill_color", "group___graphics_context.html#ga891b4629c483386546a9fe20d36bbfa9", null ],
    [ "graphics_context_set_stroke_color", "group___graphics_context.html#ga22a22f399842bcaef72842d64e0195fd", null ],
    [ "graphics_context_set_stroke_width", "group___graphics_context.html#ga18a48052681339dd0d157078117f813b", null ],
    [ "graphics_context_set_text_color", "group___graphics_context.html#gabf002f4de8793c7d2f4a804a4a438ac9", null ]
];