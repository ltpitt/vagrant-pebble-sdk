var group___number_window =
[
    [ "number_window_create", "group___number_window.html#ga982395aad6f12cd46f0004f27ede215b", null ],
    [ "number_window_destroy", "group___number_window.html#ga277a36f4533d07485db71d6e615e07a1", null ],
    [ "number_window_get_value", "group___number_window.html#ga035ef25b3c5ffc254df062cab1b4f9ec", null ],
    [ "number_window_get_window", "group___number_window.html#ga80057205732a3815fff2c730b4ba663c", null ],
    [ "number_window_set_label", "group___number_window.html#gadb5c0553f2f6d720c24b79eab033b16a", null ],
    [ "number_window_set_max", "group___number_window.html#ga07b009ae91d3ec4174a8d4f107010760", null ],
    [ "number_window_set_min", "group___number_window.html#ga95e99edee6680b64afc7ac4fca6805e6", null ],
    [ "number_window_set_step_size", "group___number_window.html#ga06fb891c949608321679dbc712a34078", null ],
    [ "number_window_set_value", "group___number_window.html#ga3ad7755a252e1b38f9923b126463bab8", null ],
    [ "NumberWindowCallback", "group___number_window.html#ga2d554bde8f163783375762edb9def662", null ]
];