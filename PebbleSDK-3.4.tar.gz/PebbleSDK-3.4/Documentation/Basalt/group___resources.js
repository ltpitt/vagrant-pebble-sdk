var group___resources =
[
    [ "File Formats", "group___file_formats.html", "group___file_formats" ],
    [ "resource_get_handle", "group___resources.html#ga3f32b97d857618e5772f72d8e2dbc566", null ],
    [ "resource_load", "group___resources.html#gac6f18e9be286b9f2a783a63234f2288d", null ],
    [ "resource_load_byte_range", "group___resources.html#ga080fa15487f08923b4529314bcf00965", null ],
    [ "resource_size", "group___resources.html#gaff5c1478dd149d241ba85a115c486779", null ],
    [ "ResHandle", "group___resources.html#gabc5102ad91f29ffca2b77dce7caa8664", null ]
];