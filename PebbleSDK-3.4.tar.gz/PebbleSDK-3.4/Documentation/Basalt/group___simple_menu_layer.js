var group___simple_menu_layer =
[
    [ "simple_menu_layer_create", "group___simple_menu_layer.html#ga8cb9fa4fbe318289989506ba49f228f5", null ],
    [ "simple_menu_layer_destroy", "group___simple_menu_layer.html#ga0608656e550deb3b0339cd1c807990e2", null ],
    [ "simple_menu_layer_get_layer", "group___simple_menu_layer.html#ga084151685bf2cadc5efaa52ee534c020", null ],
    [ "simple_menu_layer_get_menu_layer", "group___simple_menu_layer.html#gaf4fe6986f8dd03cd5f260148d906171c", null ],
    [ "simple_menu_layer_get_selected_index", "group___simple_menu_layer.html#ga496b6f0e2b65a70715d01d3d2630d215", null ],
    [ "simple_menu_layer_set_selected_index", "group___simple_menu_layer.html#gad1a4c28d39c0aa4bcad32920ec0f2e75", null ],
    [ "SimpleMenuLayerSelectCallback", "group___simple_menu_layer.html#gac877ef0d29ee59537df4da1e9e226c1a", null ]
];