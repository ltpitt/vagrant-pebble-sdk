var group___smartstrap =
[
    [ "smartstrap_attribute_begin_write", "group___smartstrap.html#ga213a819d247369ec0104c6cdf491e54f", null ],
    [ "smartstrap_attribute_create", "group___smartstrap.html#ga5465f56e748afa55ba3fb9fda145259e", null ],
    [ "smartstrap_attribute_destroy", "group___smartstrap.html#ga078a16b08dbc08080358cbea3dab6a86", null ],
    [ "smartstrap_attribute_end_write", "group___smartstrap.html#ga1eceb872794eb6523ec365dbaca30575", null ],
    [ "smartstrap_attribute_get_attribute_id", "group___smartstrap.html#ga704e596ad8a914a8ea9eabc2ecf566ae", null ],
    [ "smartstrap_attribute_get_service_id", "group___smartstrap.html#ga55a0a201de9fb28d397e89e3d9916a40", null ],
    [ "smartstrap_attribute_read", "group___smartstrap.html#gabb0da17b41d48b01aa545786671275b6", null ],
    [ "smartstrap_service_is_available", "group___smartstrap.html#gad64edbf8e9cd6b7abc4e11fc74e63eb9", null ],
    [ "smartstrap_set_timeout", "group___smartstrap.html#ga48c5b65d9f8d0070854d9451a26ec30e", null ],
    [ "smartstrap_subscribe", "group___smartstrap.html#ga5a78e451bd596692e0affbdcc01eae50", null ],
    [ "smartstrap_unsubscribe", "group___smartstrap.html#ga7ebbfcea4142202197d8595f04aee9fc", null ],
    [ "SmartstrapAttribute", "group___smartstrap.html#ga4ea96ce94fb4765d39d9c70eff321569", null ],
    [ "SmartstrapAttributeId", "group___smartstrap.html#gabbc436295eaf481c9358813990f85330", null ],
    [ "SmartstrapNotifyHandler", "group___smartstrap.html#ga9313158f3cee09852d99791b0131eb5f", null ],
    [ "SmartstrapReadHandler", "group___smartstrap.html#gab1a52470270a95939e75937cd6197210", null ],
    [ "SmartstrapServiceAvailabilityHandler", "group___smartstrap.html#gad58e09e55f7bbf0a2dcc00295fcd5d66", null ],
    [ "SmartstrapServiceId", "group___smartstrap.html#ga1ce83768c0652417bf8d273223655b0c", null ],
    [ "SmartstrapWriteHandler", "group___smartstrap.html#gaeb114beb6e28ba7458ad9aa296d46825", null ],
    [ "SmartstrapResult", "group___smartstrap.html#ga84dc8e008822a759ff6823c06829ac8a", [
      [ "SmartstrapResultOk", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aaf66884579bfb6a44ec70593f367dc9e6", null ],
      [ "SmartstrapResultInvalidArgs", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aa0152802341ba22126dd6fb03d9934270", null ],
      [ "SmartstrapResultNotPresent", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aa84771fd8db30b2ea6fa1005687589191", null ],
      [ "SmartstrapResultBusy", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aa0e3cc753c1e608db2f41a6c23556aeb8", null ],
      [ "SmartstrapResultServiceUnavailable", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aa0cf226372cc1c5cdf264f926497ee3a5", null ],
      [ "SmartstrapResultAttributeUnsupported", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aad0dde868cc4ea35d7d7b05155e5727cd", null ],
      [ "SmartstrapResultTimeOut", "group___smartstrap.html#gga84dc8e008822a759ff6823c06829ac8aa21cf4c71d56ba7c84805b9908c204e1d", null ]
    ] ],
    [ "SMARTSTRAP_RAW_DATA_ATTRIBUTE_ID", "group___smartstrap.html#ga65820921e9784db17cfe8d5deef8f058", null ],
    [ "SMARTSTRAP_RAW_DATA_SERVICE_ID", "group___smartstrap.html#ga4474a7976feaad01871ea8bd3f8ee2f6", null ],
    [ "SMARTSTRAP_TIMEOUT_DEFAULT", "group___smartstrap.html#ga6c7eaabf882a7666ff5a541644bb74c5", null ]
];