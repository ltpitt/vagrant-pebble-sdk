var group___standard_memory =
[
    [ "calloc", "group___standard_memory.html#gad65564be3c3e7ff6f7586303aebf9949", null ],
    [ "free", "group___standard_memory.html#gafbedc913aa4651b3c3b4b3aecd9b4711", null ],
    [ "malloc", "group___standard_memory.html#ga9c36d0fe3ec4675cbffdc9b52f5fb399", null ],
    [ "memcpy", "group___standard_memory.html#gaba088e716bccbc96d42da97e96316df1", null ],
    [ "memmove", "group___standard_memory.html#ga340d11725e5c81a874f508fbcdf1c5ef", null ],
    [ "memset", "group___standard_memory.html#ga1dfdc55c5334154353963674598faf1b", null ],
    [ "realloc", "group___standard_memory.html#gad28fed1039f35d754710633141b4edf0", null ],
    [ "size_t", "group___standard_memory.html#ga7b60c5629e55e8ec87a4547dd4abced4", null ]
];