var group___standard_time =
[
    [ "difftime", "group___standard_time.html#ga401df150393f329cc4230033b6305a15", null ],
    [ "gmtime", "group___standard_time.html#gab8c68cab16dbf9f2c5eadfaa49e34ac8", null ],
    [ "localtime", "group___standard_time.html#gab78e33846b47fd18f359045d6ca762d2", null ],
    [ "mktime", "group___standard_time.html#ga308ef252844d2144895207aa52e6a89f", null ],
    [ "strftime", "group___standard_time.html#ga03c7f6e1209ced1ebc8accd5fd9eaa3c", null ],
    [ "time", "group___standard_time.html#ga99ef1cb2c789827dd5db3886dccf9067", null ],
    [ "time_ms", "group___standard_time.html#gaa650308d93a4da6ead47ae68372f2be8", null ],
    [ "time_t", "group___standard_time.html#gaffa4d193759c763a2623cc49d69b15f5", null ]
];