var group___status_bar_layer =
[
    [ "status_bar_layer_create", "group___status_bar_layer.html#ga8b9a620789158edbfe2b5760f7c5b09f", null ],
    [ "status_bar_layer_destroy", "group___status_bar_layer.html#ga8888bc8140ee6693e8221b805043d1fb", null ],
    [ "status_bar_layer_get_background_color", "group___status_bar_layer.html#ga2a25ec0661cce481fdf30048f510142a", null ],
    [ "status_bar_layer_get_foreground_color", "group___status_bar_layer.html#ga2fdfa31254d64f33c5d3c5b00ce160dd", null ],
    [ "status_bar_layer_get_layer", "group___status_bar_layer.html#ga2583a625d69de030949638421aac7b61", null ],
    [ "status_bar_layer_set_colors", "group___status_bar_layer.html#ga818d409a6c42775771c3febf03e10e92", null ],
    [ "status_bar_layer_set_separator_mode", "group___status_bar_layer.html#ga8372ccc195ab25b123a3d3c9244bace4", null ],
    [ "StatusBarLayerSeparatorMode", "group___status_bar_layer.html#gaf7316a23f8fa3b482551ea4cbbb414fa", [
      [ "StatusBarLayerSeparatorModeNone", "group___status_bar_layer.html#ggaf7316a23f8fa3b482551ea4cbbb414faa5fd87a47081ee5add2afa2d67d3ab9c6", null ],
      [ "StatusBarLayerSeparatorModeDotted", "group___status_bar_layer.html#ggaf7316a23f8fa3b482551ea4cbbb414faa15cfb9da70e7753b3e8efeaedaa1b318", null ]
    ] ]
];