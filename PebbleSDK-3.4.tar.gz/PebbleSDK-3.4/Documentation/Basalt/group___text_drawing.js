var group___text_drawing =
[
    [ "graphics_draw_text", "group___text_drawing.html#ga876d51066b9015f2fccd784186c4620d", null ],
    [ "graphics_text_layout_get_content_size", "group___text_drawing.html#ga4e3ae8151d8d57e23fc160251242face", null ],
    [ "GTextLayoutCacheRef", "group___text_drawing.html#gaf1a8558f11138c8b1a4993d8de10c490", null ],
    [ "GTextAlignment", "group___text_drawing.html#ga12cbd02b0d5668d7c9bd582077bf7f1d", [
      [ "GTextAlignmentLeft", "group___text_drawing.html#gga12cbd02b0d5668d7c9bd582077bf7f1da1c91d07ea9ed1ecbb9d01c2a2d0a369a", null ],
      [ "GTextAlignmentCenter", "group___text_drawing.html#gga12cbd02b0d5668d7c9bd582077bf7f1da96946af7ae1aa2183ff953e0b053b79a", null ],
      [ "GTextAlignmentRight", "group___text_drawing.html#gga12cbd02b0d5668d7c9bd582077bf7f1dadcbf1860911da6d573d76430e162f230", null ]
    ] ],
    [ "GTextOverflowMode", "group___text_drawing.html#gadad5abc1b1cfbddd48bd79f70c05b8fa", [
      [ "GTextOverflowModeWordWrap", "group___text_drawing.html#ggadad5abc1b1cfbddd48bd79f70c05b8faa6ae3728d53a3ff07b28f8b72f60226b9", null ],
      [ "GTextOverflowModeTrailingEllipsis", "group___text_drawing.html#ggadad5abc1b1cfbddd48bd79f70c05b8faa346a4ac943012d3e193452bfba04f6c5", null ],
      [ "GTextOverflowModeFill", "group___text_drawing.html#ggadad5abc1b1cfbddd48bd79f70c05b8faad0ca30172597863ea2894dd5d4e16ebf", null ]
    ] ]
];