var group___u_u_i_d =
[
    [ "uuid_equal", "group___u_u_i_d.html#gaf3672abb648800ef789f52078fe25a37", null ],
    [ "uuid_to_string", "group___u_u_i_d.html#gaedb2683d7b3bf3b65a19b487f4ac6147", null ],
    [ "UUID_STRING_BUFFER_LENGTH", "group___u_u_i_d.html#ga8bcd1589d1f13e8b9590e1ac4fc105a6", null ],
    [ "UuidMake", "group___u_u_i_d.html#ga9128d7f2d76acf429e4f87120ae85264", null ],
    [ "UuidMakeFromBEBytes", "group___u_u_i_d.html#ga6f6051dfaa96cba4a771cbc172df174c", null ],
    [ "UuidMakeFromLEBytes", "group___u_u_i_d.html#ga2edca35e11dd848805ee37ee54751b22", null ]
];