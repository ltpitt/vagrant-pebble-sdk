var group___window =
[
    [ "ActionMenu", "group___action_menu.html", "group___action_menu" ],
    [ "NumberWindow", "group___number_window.html", "group___number_window" ],
    [ "window_create", "group___window.html#gad97e085cc35ca1f5a6f713918089374c", null ],
    [ "window_destroy", "group___window.html#ga820c1ac9478c640ee5c43ec79c70ce47", null ],
    [ "window_get_click_config_context", "group___window.html#ga5be1adcc8915381d97b9b268d089d496", null ],
    [ "window_get_click_config_provider", "group___window.html#ga22519bc087f0779705c5981eff3e030f", null ],
    [ "window_get_root_layer", "group___window.html#ga8a0233aa7927ebc51a0b2d8708f52fe0", null ],
    [ "window_get_user_data", "group___window.html#ga9292027b4df03c42e9f096ef777f9220", null ],
    [ "window_is_loaded", "group___window.html#ga8e55dedc20b8f2000993fc3c937f4ea9", null ],
    [ "window_long_click_subscribe", "group___window.html#ga3329027de707b949f02328492165cf05", null ],
    [ "window_multi_click_subscribe", "group___window.html#ga041018e3b3db5bb7866283fffcd4b766", null ],
    [ "window_raw_click_subscribe", "group___window.html#ga6cecc4f27755aaf91f1f232c4c6f8b16", null ],
    [ "window_set_background_color", "group___window.html#gafbec4ea556f6015c6cd4c81dacb50c8f", null ],
    [ "window_set_click_config_provider", "group___window.html#gaeefbe33bc69ffee444337b056912440c", null ],
    [ "window_set_click_config_provider_with_context", "group___window.html#gadfbe85cbdb8a0b96d970672639c5421e", null ],
    [ "window_set_click_context", "group___window.html#gab3b456b676a771612e0d8f254bd7e05c", null ],
    [ "window_set_user_data", "group___window.html#gaaec64431b5c68ffbd51d6c9055891455", null ],
    [ "window_set_window_handlers", "group___window.html#gac59cf99a62ff53b5b4a25c6432438360", null ],
    [ "window_single_click_subscribe", "group___window.html#gae09d8d7299a9d5a750a898a70f64bdec", null ],
    [ "window_single_repeating_click_subscribe", "group___window.html#ga1ff2467f009b80f8bc97ef197e34d332", null ],
    [ "WindowHandler", "group___window.html#gafaf0ee4d0dfa0475ecbb37b387eb87e8", null ]
];