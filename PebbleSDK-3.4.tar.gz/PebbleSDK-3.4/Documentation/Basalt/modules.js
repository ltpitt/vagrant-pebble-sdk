var modules =
[
    [ "Foundation", "group___foundation.html", "group___foundation" ],
    [ "Graphics", "group___graphics.html", "group___graphics" ],
    [ "Profiling", "group___profiling.html", null ],
    [ "Smartstrap", "group___smartstrap.html", "group___smartstrap" ],
    [ "Standard C", "group___standard_c.html", "group___standard_c" ],
    [ "User Interface", "group___u_i.html", "group___u_i" ],
    [ "Worker", "group___worker.html", "group___worker" ]
];