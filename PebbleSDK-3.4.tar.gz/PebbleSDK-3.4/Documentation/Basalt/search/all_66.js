var searchData=
[
  ['file_20formats',['File Formats',['../group___file_formats.html',1,'']]],
  ['fonts',['Fonts',['../group___fonts.html',1,'']]],
  ['fonts_5fget_5fsystem_5ffont',['fonts_get_system_font',['../group___fonts.html#ga8d05ec62a2e79c75b2938c2e2d6ba70a',1,'pebble.h']]],
  ['fonts_5fload_5fcustom_5ffont',['fonts_load_custom_font',['../group___fonts.html#gaaf4a526b0bbe417959eb7935b89a5f56',1,'pebble.h']]],
  ['fonts_5funload_5fcustom_5ffont',['fonts_unload_custom_font',['../group___fonts.html#gae25249ea28fddf938ef900efdcf1777c',1,'pebble.h']]],
  ['foundation',['Foundation',['../group___foundation.html',1,'']]],
  ['free',['free',['../group___standard_memory.html#gafbedc913aa4651b3c3b4b3aecd9b4711',1,'common.dox']]],
  ['friday',['FRIDAY',['../group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a8f589731fd90a9890c0df9a9c3f96131',1,'pebble.h']]],
  ['format',['Format',['../group___standard_i_o.html',1,'']]]
];
