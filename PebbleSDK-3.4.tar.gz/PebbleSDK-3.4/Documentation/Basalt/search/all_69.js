var searchData=
[
  ['i18n_5fget_5fsystem_5flocale',['i18n_get_system_locale',['../group___internationalization.html#gaab8c203d34253c4cedf7dd2debb02bfb',1,'pebble.h']]],
  ['icon',['icon',['../group___simple_menu_layer.html#abdcb2509876059ad6c0f2a887927f952',1,'SimpleMenuItem']]],
  ['incremented',['incremented',['../group___number_window.html#a859555b6e90e9f30ebf83ade1843edb4',1,'NumberWindowCallbacks']]],
  ['int16getter',['Int16Getter',['../group___property_animation.html#ga89f63a97d7bc1f842f3826005100ac8e',1,'pebble.h']]],
  ['int16setter',['Int16Setter',['../group___property_animation.html#gaa7ff134ddfbf52b7ea200414796640f2',1,'pebble.h']]],
  ['internationalization',['Internationalization',['../group___internationalization.html',1,'']]],
  ['is_5fcharging',['is_charging',['../group___battery_state_service.html#a1a2d28c28d3d230b5f8fe2fd089ff9dd',1,'BatteryChargeState']]],
  ['is_5fdeclination_5fvalid',['is_declination_valid',['../group___compass_service.html#a244791d533094a407a3879686d532afd',1,'CompassHeadingData']]],
  ['is_5fplugged',['is_plugged',['../group___battery_state_service.html#a00910c85f1f068363a7b400151b7f8e4',1,'BatteryChargeState']]],
  ['items',['items',['../group___simple_menu_layer.html#a377ff366a71e19cfe6c1dbb8f233f91b',1,'SimpleMenuSection']]]
];
