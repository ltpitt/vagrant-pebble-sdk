var searchData=
[
  ['offset',['offset',['../group___path_drawing.html#ae15e816101f2e18925105c5a6be04392',1,'GPath']]],
  ['origin',['origin',['../group___graphics_types.html#a28af4b04e081517f4f546c4af5b44612',1,'GRect']]]
];
