var searchData=
[
  ['galign',['GAlign',['../group___graphics_types.html#gac8aa0eb3d3065fde8d2d6f282fa47f6a',1,'pebble.h']]],
  ['gbitmapformat',['GBitmapFormat',['../group___graphics_types.html#ga5c29b6b52478182a01ec4863de80ebfa',1,'pebble.h']]],
  ['gcompop',['GCompOp',['../group___graphics_types.html#ga0d021422bd90a2a49e6c8d848e6d556f',1,'pebble.h']]],
  ['gcornermask',['GCornerMask',['../group___drawing.html#gae0e0ea29942e8ae8fe4a7201adbd1b72',1,'pebble.h']]],
  ['gdrawcommandtype',['GDrawCommandType',['../group___draw_command.html#gacf7487ecae2c3be099135069a81ec742',1,'pebble.h']]],
  ['gtextalignment',['GTextAlignment',['../group___text_drawing.html#ga12cbd02b0d5668d7c9bd582077bf7f1d',1,'pebble.h']]],
  ['gtextoverflowmode',['GTextOverflowMode',['../group___text_drawing.html#gadad5abc1b1cfbddd48bd79f70c05b8fa',1,'pebble.h']]]
];
