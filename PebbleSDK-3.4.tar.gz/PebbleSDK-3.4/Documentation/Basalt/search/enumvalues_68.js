var searchData=
[
  ['hour_5funit',['HOUR_UNIT',['../group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107a7628af862ee9aa0b56cdfc1cea7e0f79',1,'pebble.h']]]
];
