var searchData=
[
  ['battery_5fstate_5fservice_5fpeek',['battery_state_service_peek',['../group___battery_state_service.html#ga0db4a30663844c173acb72f9204e6fcb',1,'pebble.h']]],
  ['battery_5fstate_5fservice_5fsubscribe',['battery_state_service_subscribe',['../group___battery_state_service.html#gadef114a27f24cc39e3ee5bda3756c865',1,'pebble.h']]],
  ['battery_5fstate_5fservice_5funsubscribe',['battery_state_service_unsubscribe',['../group___battery_state_service.html#ga787d24a03fe9a51cd61e24a9775efbc6',1,'pebble.h']]],
  ['bitmap_5flayer_5fcreate',['bitmap_layer_create',['../group___bitmap_layer.html#ga3fa77622a7b1ea656f0503dfadeea712',1,'pebble.h']]],
  ['bitmap_5flayer_5fdestroy',['bitmap_layer_destroy',['../group___bitmap_layer.html#ga4ef30a7562a029d81e2956ab8068f0f5',1,'pebble.h']]],
  ['bitmap_5flayer_5fget_5fbitmap',['bitmap_layer_get_bitmap',['../group___bitmap_layer.html#gabe873bfc58601ef31730591192e16b45',1,'pebble.h']]],
  ['bitmap_5flayer_5fget_5flayer',['bitmap_layer_get_layer',['../group___bitmap_layer.html#gac9147d277bf7e57b5efcaebf8db3f0b2',1,'pebble.h']]],
  ['bitmap_5flayer_5fset_5falignment',['bitmap_layer_set_alignment',['../group___bitmap_layer.html#ga4c1765f9330890641c4c09ba7e894894',1,'pebble.h']]],
  ['bitmap_5flayer_5fset_5fbackground_5fcolor',['bitmap_layer_set_background_color',['../group___bitmap_layer.html#ga67522a1e62431f0f68d161d83fb6d83e',1,'pebble.h']]],
  ['bitmap_5flayer_5fset_5fbitmap',['bitmap_layer_set_bitmap',['../group___bitmap_layer.html#ga919b52c2feb69c13966f4a52815377f8',1,'pebble.h']]],
  ['bitmap_5flayer_5fset_5fcompositing_5fmode',['bitmap_layer_set_compositing_mode',['../group___bitmap_layer.html#ga7bc761ca8227881c5853cbc0e279385e',1,'pebble.h']]],
  ['bluetooth_5fconnection_5fservice_5fpeek',['bluetooth_connection_service_peek',['../group___bluetooth_connection_service.html#ga31ae0c22e1cbf2af34b39b49e98c777a',1,'pebble.h']]],
  ['bluetooth_5fconnection_5fservice_5fsubscribe',['bluetooth_connection_service_subscribe',['../group___bluetooth_connection_service.html#ga6661ab4bdb986715602183b7849ffe84',1,'pebble.h']]],
  ['bluetooth_5fconnection_5fservice_5funsubscribe',['bluetooth_connection_service_unsubscribe',['../group___bluetooth_connection_service.html#gae3a446e0d93d0d71f4265d5ff9352c0a',1,'pebble.h']]]
];
