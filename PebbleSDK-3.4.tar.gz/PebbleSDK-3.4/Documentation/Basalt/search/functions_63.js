var searchData=
[
  ['calloc',['calloc',['../group___standard_memory.html#gad65564be3c3e7ff6f7586303aebf9949',1,'common.dox']]],
  ['click_5fnumber_5fof_5fclicks_5fcounted',['click_number_of_clicks_counted',['../group___clicks.html#ga915cc99892dba2548494a9cc2b104dd7',1,'pebble.h']]],
  ['click_5frecognizer_5fget_5fbutton_5fid',['click_recognizer_get_button_id',['../group___clicks.html#ga373020cf179b975eb53636154a9c6ce5',1,'pebble.h']]],
  ['click_5frecognizer_5fis_5frepeating',['click_recognizer_is_repeating',['../group___clicks.html#gae9b3816aa6c1a9ebbc77ad621284b5b6',1,'pebble.h']]],
  ['clock_5fcopy_5ftime_5fstring',['clock_copy_time_string',['../group___wall_time.html#ga5ddf6b7454fd49c0eb63d2e50d75fad7',1,'pebble.h']]],
  ['clock_5fget_5ftimezone',['clock_get_timezone',['../group___wall_time.html#gae34db14b2f1e369c23894bffb6663fc8',1,'pebble.h']]],
  ['clock_5fis_5f24h_5fstyle',['clock_is_24h_style',['../group___wall_time.html#ga69393fbc51be905740fff59a150bdca9',1,'pebble.h']]],
  ['clock_5fis_5ftimezone_5fset',['clock_is_timezone_set',['../group___wall_time.html#ga95c658aa0d511e4b4ca549724e02ce72',1,'pebble.h']]],
  ['clock_5fto_5ftimestamp',['clock_to_timestamp',['../group___wall_time.html#ga170869bfe009abc85f093b0f80224009',1,'pebble.h']]],
  ['compass_5fservice_5fpeek',['compass_service_peek',['../group___compass_service.html#ga7339dd85a84316f71c8d9a2912900034',1,'pebble.h']]],
  ['compass_5fservice_5fset_5fheading_5ffilter',['compass_service_set_heading_filter',['../group___compass_service.html#gad4bad2397ca6127b958fc8a8d255c411',1,'pebble.h']]],
  ['compass_5fservice_5fsubscribe',['compass_service_subscribe',['../group___compass_service.html#gae2b8f9e053a9f879f43aa17ef5af5e66',1,'pebble.h']]],
  ['compass_5fservice_5funsubscribe',['compass_service_unsubscribe',['../group___compass_service.html#gaecea99c12825526be416db6b5c69a871',1,'pebble.h']]],
  ['cos_5flookup',['cos_lookup',['../group___math.html#gaa8938fd0e58aed9906ecccacd8fde88c',1,'pebble.h']]]
];
