var searchData=
[
  ['fonts_5fget_5fsystem_5ffont',['fonts_get_system_font',['../group___fonts.html#ga8d05ec62a2e79c75b2938c2e2d6ba70a',1,'pebble.h']]],
  ['fonts_5fload_5fcustom_5ffont',['fonts_load_custom_font',['../group___fonts.html#gaaf4a526b0bbe417959eb7935b89a5f56',1,'pebble.h']]],
  ['fonts_5funload_5fcustom_5ffont',['fonts_unload_custom_font',['../group___fonts.html#gae25249ea28fddf938ef900efdcf1777c',1,'pebble.h']]],
  ['free',['free',['../group___standard_memory.html#gafbedc913aa4651b3c3b4b3aecd9b4711',1,'common.dox']]]
];
