var searchData=
[
  ['rand',['rand',['../group___standard_math.html#ga20e50ab9d6b10af0e2940d9419448f42',1,'common.dox']]],
  ['realloc',['realloc',['../group___standard_memory.html#gad28fed1039f35d754710633141b4edf0',1,'common.dox']]],
  ['resource_5fget_5fhandle',['resource_get_handle',['../group___resources.html#ga3f32b97d857618e5772f72d8e2dbc566',1,'pebble.h']]],
  ['resource_5fload',['resource_load',['../group___resources.html#gac6f18e9be286b9f2a783a63234f2288d',1,'pebble.h']]],
  ['resource_5fload_5fbyte_5frange',['resource_load_byte_range',['../group___resources.html#ga080fa15487f08923b4529314bcf00965',1,'pebble.h']]],
  ['resource_5fsize',['resource_size',['../group___resources.html#gaff5c1478dd149d241ba85a115c486779',1,'pebble.h']]],
  ['rot_5fbitmap_5flayer_5fcreate',['rot_bitmap_layer_create',['../group___rot_bitmap_layer.html#ga8813c8dda16b21688de6492540b8c69e',1,'pebble.h']]],
  ['rot_5fbitmap_5flayer_5fdestroy',['rot_bitmap_layer_destroy',['../group___rot_bitmap_layer.html#ga8b3b96d607c07aa1a64a0bf6c78f5bf5',1,'pebble.h']]],
  ['rot_5fbitmap_5flayer_5fincrement_5fangle',['rot_bitmap_layer_increment_angle',['../group___rot_bitmap_layer.html#ga1392050689ca39d86949c8b4744ddaa2',1,'pebble.h']]],
  ['rot_5fbitmap_5flayer_5fset_5fangle',['rot_bitmap_layer_set_angle',['../group___rot_bitmap_layer.html#ga0aa9e535226e88bad75410ce177c27af',1,'pebble.h']]],
  ['rot_5fbitmap_5flayer_5fset_5fcorner_5fclip_5fcolor',['rot_bitmap_layer_set_corner_clip_color',['../group___rot_bitmap_layer.html#ga05bb6f3e05c774b3e20b8ff4d1068d67',1,'pebble.h']]],
  ['rot_5fbitmap_5fset_5fcompositing_5fmode',['rot_bitmap_set_compositing_mode',['../group___rot_bitmap_layer.html#ga5ddf5cbe3499a3ee5487e82d5d5659d2',1,'pebble.h']]],
  ['rot_5fbitmap_5fset_5fsrc_5fic',['rot_bitmap_set_src_ic',['../group___rot_bitmap_layer.html#ga455a2e9f47703fe44a1054ff02396162',1,'pebble.h']]]
];
