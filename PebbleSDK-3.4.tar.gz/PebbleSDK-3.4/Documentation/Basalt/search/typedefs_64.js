var searchData=
[
  ['dictionarykeyupdatedcallback',['DictionaryKeyUpdatedCallback',['../group___dictionary.html#ga99b02996e555fcbaa01c456501dfb384',1,'pebble.h']]],
  ['dictionaryserializecallback',['DictionarySerializeCallback',['../group___dictionary.html#ga41471ee8f71754cbaf16fd0ea27c5b58',1,'pebble.h']]]
];
