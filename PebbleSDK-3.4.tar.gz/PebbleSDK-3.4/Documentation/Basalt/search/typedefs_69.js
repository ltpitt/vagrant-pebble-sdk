var searchData=
[
  ['int16getter',['Int16Getter',['../group___property_animation.html#ga89f63a97d7bc1f842f3826005100ac8e',1,'pebble.h']]],
  ['int16setter',['Int16Setter',['../group___property_animation.html#gaa7ff134ddfbf52b7ea200414796640f2',1,'pebble.h']]]
];
