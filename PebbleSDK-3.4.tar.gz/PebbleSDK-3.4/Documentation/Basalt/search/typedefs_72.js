var searchData=
[
  ['reshandle',['ResHandle',['../group___resources.html#gabc5102ad91f29ffca2b77dce7caa8664',1,'pebble.h']]]
];
