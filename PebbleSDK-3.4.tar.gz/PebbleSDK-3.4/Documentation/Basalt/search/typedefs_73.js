var searchData=
[
  ['scrolllayercallback',['ScrollLayerCallback',['../group___scroll_layer.html#ga562d848f7db8d2c1fa10d99b256a8b3c',1,'pebble.h']]],
  ['simplemenulayerselectcallback',['SimpleMenuLayerSelectCallback',['../group___simple_menu_layer.html#gac877ef0d29ee59537df4da1e9e226c1a',1,'pebble.h']]],
  ['size_5ft',['size_t',['../group___standard_memory.html#ga7b60c5629e55e8ec87a4547dd4abced4',1,'common.dox']]],
  ['smartstrapattribute',['SmartstrapAttribute',['../group___smartstrap.html#ga4ea96ce94fb4765d39d9c70eff321569',1,'pebble.h']]],
  ['smartstrapattributeid',['SmartstrapAttributeId',['../group___smartstrap.html#gabbc436295eaf481c9358813990f85330',1,'pebble.h']]],
  ['smartstrapnotifyhandler',['SmartstrapNotifyHandler',['../group___smartstrap.html#ga9313158f3cee09852d99791b0131eb5f',1,'pebble.h']]],
  ['smartstrapreadhandler',['SmartstrapReadHandler',['../group___smartstrap.html#gab1a52470270a95939e75937cd6197210',1,'pebble.h']]],
  ['smartstrapserviceavailabilityhandler',['SmartstrapServiceAvailabilityHandler',['../group___smartstrap.html#gad58e09e55f7bbf0a2dcc00295fcd5d66',1,'pebble.h']]],
  ['smartstrapserviceid',['SmartstrapServiceId',['../group___smartstrap.html#ga1ce83768c0652417bf8d273223655b0c',1,'pebble.h']]],
  ['smartstrapwritehandler',['SmartstrapWriteHandler',['../group___smartstrap.html#gaeb114beb6e28ba7458ad9aa296d46825',1,'pebble.h']]],
  ['status_5ft',['status_t',['../group___storage.html#gaaabdaf7ee58ca7269bd4bf24efcde092',1,'pebble.h']]]
];
