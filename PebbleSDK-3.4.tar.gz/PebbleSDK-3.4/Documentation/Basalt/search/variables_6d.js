var searchData=
[
  ['magnetic_5fheading',['magnetic_heading',['../group___compass_service.html#ac2e476c83c6946877eedb0b471ff9cff',1,'CompassHeadingData']]],
  ['major',['major',['../group___watch_info.html#a1e7b5ff37561b37e7defc5d9925dca2f',1,'WatchInfoVersion']]],
  ['minor',['minor',['../group___watch_info.html#a12ded59fd8f84d4c86b0a5cb6f91b08c',1,'WatchInfoVersion']]]
];
