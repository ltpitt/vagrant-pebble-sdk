var searchData=
[
  ['patch',['patch',['../group___watch_info.html#a820d5cf455587c5936f77857aa345c91',1,'WatchInfoVersion']]],
  ['points',['points',['../group___path_drawing.html#a9060d72e677cfa33dc4c26e0829299c6',1,'GPathInfo::points()'],['../group___path_drawing.html#a1c38d8ee2e1f7f9fd288bc39fa958190',1,'GPath::points()']]]
];
