var searchData=
[
  ['root_5flevel',['root_level',['../group___action_menu.html#ab1ddd5b3a602bfc7a383854c672e12ec',1,'ActionMenuConfig']]],
  ['rotation',['rotation',['../group___path_drawing.html#aeb2d6125fb6fb0e41711d1d65607b983',1,'GPath']]],
  ['row',['row',['../group___menu_layer.html#abdefc68549bda67cfbae350ba78c6b59',1,'MenuIndex']]]
];
