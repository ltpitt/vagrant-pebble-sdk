var searchData=
[
  ['w',['w',['../group___graphics_types.html#ab4b00bc79cc43d5554d19fd273fe37e0',1,'GSize']]],
  ['will_5fclose',['will_close',['../group___action_menu.html#a88e39a8e30efbaf4668509fff34b7f17',1,'ActionMenuConfig']]],
  ['will_5ffocus',['will_focus',['../group___app_focus_service.html#a6f30cc68eec1ca941a2af248d3c7c34b',1,'AppFocusHandlers']]]
];
