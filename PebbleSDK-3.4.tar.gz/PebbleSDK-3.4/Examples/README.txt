You can find all the official SDK examples in individual repositories under pebble-examples on GitHub.

https://github.com/pebble-examples/
