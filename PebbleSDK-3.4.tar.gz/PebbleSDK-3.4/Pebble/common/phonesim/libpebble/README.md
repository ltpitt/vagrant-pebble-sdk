libpebble and pb-sdk
====================

Those tools that are now part of Pebble SDK are based on the original libpebble by Hexxeh (Liam McLoughlin).

Original project: https://github.com/Hexxeh/libpebble

This version of libpebble can talk to the Pebble watch through your smartphone using websockets instead of directly to the watch using Bluetooth. As of SDK 2.0, this is the recommended way. However, it is still possible to establish a direct Bluetooth connection to the watch with LightBlue.

Refer to Pebble SDK Documentation for help on using pb-sdk.py.
